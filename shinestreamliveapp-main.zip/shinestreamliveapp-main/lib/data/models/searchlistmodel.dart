class MovieList{ //modal class for Person object
  String videoId;
  String title;
  String thumbnail;
  String ratings;
  String videoPrice;
  MovieList({required this.videoId, required this.title, required this.thumbnail, required this.ratings,required this.videoPrice});
}