class FontFamilyConstants{
  static String interBlack = "Inter-black";
  static String interBold = "Inter-bold";
  static String interExtraBold = "Inter-extrabold";
  static String interLight = "Inter-light";
  static String interMedium = "Inter-medium";
  static String interRegular = "Inter-regular";
}
