class AppAsset {

  static String freeImage = "assets/FREE PNG.png";
  static String logoMain = "assets/logomain.jpg";

  /// payment logo image
  static String paytmLogo = "assets/paymentLogo/paytmLogo.jpg";
  static String paypalLogo = "assets/paymentLogo/paypalLogo.png";



  /// language image
  static String banjaraLang = "assets/language/Banjara Poster.png";
  static String bhojPuriLang = "assets/language/Bhojpuri Poster.png";
  static String englishLang = "assets/language/English Poster.png";
  static String gujuratiLang = "assets/language/Gujurati Poster.png";
  static String hindiLang = "assets/language/Hindi Poster.png";
  static String kannadaLang = "assets/language/Kannada Poster.png";
  static String koreanLang = "assets/language/Korean Poster.png";
  static String malayalamLang = "assets/language/Malayalam Poster.png";
  static String marathiLang = "assets/language/Marathi Poster.png";
  static String nepaliLang = "assets/language/Nepali Poster.png";
  static String odiaLang = "assets/language/Odia Poster.png";
  static String punjabiLang = "assets/language/Panjabi Poster.png";
  static String tamilLang = "assets/language/Tamil Poster.png";
  static String teluguLang = "assets/language/Telugu Poster.png";



}