class SharedConstants{
  static const String accessToken = "accessToken";
  static String mobileNumber = "mobileNumber";
  static String subScription = "subScription";
    static String udid = "udid";
  static String otp = "otp";
  static String profilePic = "profilePic";
  static String userName = "userName";
  static String userEmail = "userEmail";
  static String settingsUserEmail = "settingsUserEmail";
  static String settingsUserName  = "settingsUserName";
  static String settingsUserNumber  = "settingsUserNumber";
  static String deleteUdid  = "deleteUdid";
  static String fmc  = "fcm";
}